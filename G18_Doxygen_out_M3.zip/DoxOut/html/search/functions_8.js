var searchData=
[
  ['main_260',['Main',['../class_s_q_final_project_1_1_app.html#a3e23ce1ca0669f533b9ee697110182fd',1,'SQFinalProject.App.Main()'],['../class_s_q_final_project_1_1_app.html#a3e23ce1ca0669f533b9ee697110182fd',1,'SQFinalProject.App.Main()']]],
  ['makeinsertcommand_261',['MakeInsertCommand',['../class_s_q_final_project_1_1_database.html#ae1fa67bbf3264335cafc8fcbe057d3e9',1,'SQFinalProject.Database.MakeInsertCommand(string table, List&lt; string &gt; values)'],['../class_s_q_final_project_1_1_database.html#ab7f688bb003d9d0153067ace21259cb1',1,'SQFinalProject.Database.MakeInsertCommand(string table, List&lt; string &gt; fields, List&lt; string &gt; values)']]],
  ['makeselectcommand_262',['MakeSelectCommand',['../class_s_q_final_project_1_1_database.html#a0f2a85c359020d28dcee30fcf9027910',1,'SQFinalProject::Database']]],
  ['makeupdatecommand_263',['MakeUpdateCommand',['../class_s_q_final_project_1_1_database.html#a096d4f1a9566c7e899f1491b42020166',1,'SQFinalProject::Database']]]
];
