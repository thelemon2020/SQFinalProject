var searchData=
[
  ['resources_2edesigner_2ecs_211',['Resources.Designer.cs',['../_resources_8_designer_8cs.html',1,'']]],
  ['route_2ecs_212',['Route.cs',['../_route_8cs.html',1,'']]]
];
