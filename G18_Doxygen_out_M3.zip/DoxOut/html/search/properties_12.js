var searchData=
[
  ['user_331',['user',['../class_s_q_final_project_1_1_database.html#ad1de976f754458947afe96d32a5ae1cc',1,'SQFinalProject::Database']]],
  ['usercommand_332',['userCommand',['../class_s_q_final_project_1_1_database.html#a8f417e3c75238e5c5b3687c39cdccfbe',1,'SQFinalProject::Database']]]
];
