var searchData=
[
  ['obj_282',['obj',['../class_s_q_final_project_1_1_logger.html#a12ef55ad72a7c4cd59e6458d32e77050',1,'SQFinalProject::Logger']]]
];
