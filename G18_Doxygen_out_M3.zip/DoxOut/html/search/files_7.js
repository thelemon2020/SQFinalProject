var searchData=
[
  ['settings_2edesigner_2ecs_213',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]],
  ['sqfinalproject_2ecsproj_2efilelistabsolute_2etxt_214',['SQFinalProject.csproj.FileListAbsolute.txt',['../_s_q_final_project_8csproj_8_file_list_absolute_8txt.html',1,'']]]
];
